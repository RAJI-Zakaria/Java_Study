package tp_input_output;

public class Exception {
	
}
